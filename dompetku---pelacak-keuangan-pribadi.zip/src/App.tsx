/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  LogOut, 
  LogIn, 
  Trash2, 
  Calendar, 
  Tag, 
  FileText,
  PieChart as PieChartIcon,
  List as ListIcon
} from 'lucide-react';
import { AuthProvider, useAuth } from './lib/AuthContext';
import { signInWithGoogle, logout } from './lib/firebase';
import { transactionService, Transaction } from './lib/transactionService';
import { formatCurrency, cn } from './lib/utils';
import { format } from 'date-fns';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';

function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center"
      >
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Wallet className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">DompetKu</h1>
        <p className="text-gray-500 mb-8">Kelola keuangan Anda dengan bijak dan mudah.</p>
        <button
          onClick={signInWithGoogle}
          className="w-full flex items-center justify-center gap-3 bg-white border border-gray-300 py-3 px-4 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-colors shadow-sm"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/02/20/google_logo.svg" className="w-5 h-5" alt="Google" />
          Masuk dengan Google
        </button>
      </motion.div>
    </div>
  );
}

function Dashboard() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    type: 'expense' as 'income' | 'expense',
    category: '',
    description: '',
    date: format(new Date(), 'yyyy-MM-dd')
  });

  useEffect(() => {
    if (user) {
      const unsubscribe = transactionService.getTransactions(user.uid, setTransactions);
      return unsubscribe;
    }
  }, [user]);

  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const balance = totalIncome - totalExpense;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    await transactionService.addTransaction(user.uid, {
      amount: Number(formData.amount),
      type: formData.type,
      category: formData.category,
      description: formData.description,
      date: new Date(formData.date)
    });

    setIsModalOpen(false);
    setFormData({
      amount: '',
      type: 'expense',
      category: '',
      description: '',
      date: format(new Date(), 'yyyy-MM-dd')
    });
  };

  const categories = transactions.reduce((acc, t) => {
    if (t.type === 'expense') {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
    }
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(categories).map(([name, value]) => ({ name, value }));
  const COLORS = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899'];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="w-6 h-6 text-blue-600" />
            <span className="font-bold text-xl text-gray-900">DompetKu</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-gray-900">{user?.displayName}</p>
              <p className="text-xs text-gray-500">{user?.email}</p>
            </div>
            <button 
              onClick={logout}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        {/* Balance Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-blue-600 rounded-2xl p-6 text-white shadow-lg shadow-blue-200 col-span-1 md:col-span-3 flex flex-col md:flex-row md:items-center justify-between gap-6"
          >
            <div>
              <p className="text-blue-100 text-sm mb-1">Total Saldo</p>
              <h2 className="text-3xl font-bold">{formatCurrency(balance)}</h2>
            </div>
            <div className="flex gap-4">
              <div className="bg-white/10 rounded-xl p-4 flex-1 backdrop-blur-sm">
                <div className="flex items-center gap-2 text-blue-100 text-xs mb-1">
                  <TrendingUp className="w-3 h-3" /> Pemasukan
                </div>
                <p className="font-semibold">{formatCurrency(totalIncome)}</p>
              </div>
              <div className="bg-white/10 rounded-xl p-4 flex-1 backdrop-blur-sm">
                <div className="flex items-center gap-2 text-blue-100 text-xs mb-1">
                  <TrendingDown className="w-3 h-3" /> Pengeluaran
                </div>
                <p className="font-semibold">{formatCurrency(totalExpense)}</p>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-gray-900 flex items-center gap-2 text-lg">
                <ListIcon className="w-5 h-5 text-gray-400" />
                Transaksi Terkini
              </h3>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-md shadow-blue-100 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Tambah
              </button>
            </div>

            <div className="space-y-3">
              {transactions.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-gray-300">
                  <p className="text-gray-500">Belum ada transaksi.</p>
                </div>
              ) : (
                transactions.map((t) => (
                  <motion.div 
                    layout
                    key={t.id}
                    className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center",
                        t.type === 'income' ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
                      )}>
                        {t.type === 'income' ? <Plus className="w-5 h-5" /> : <Minus className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{t.category}</p>
                        <p className="text-xs text-gray-500">{format(t.date, 'dd MMM yyyy')} • {t.description || 'Tanpa catatan'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <p className={cn(
                        "font-bold",
                        t.type === 'income' ? "text-green-600" : "text-red-600"
                      )}>
                        {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount)}
                      </p>
                      <button 
                        onClick={() => transactionService.deleteTransaction(user!.uid, t.id!)}
                        className="p-1 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>

          {/* Right Column: Analytics */}
          <div className="space-y-6">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 text-lg">
              <PieChartIcon className="w-5 h-5 text-gray-400" />
              Alokasi Pengeluaran
            </h3>
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm min-h-[300px]">
              {pieData.length > 0 ? (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p className="text-gray-500 text-center py-12">Data belum cukup.</p>
              )}
              
              <div className="mt-4 space-y-2">
                {pieData.map((item, idx) => (
                  <div key={item.name} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                      <span className="text-gray-600">{item.name}</span>
                    </div>
                    <span className="font-medium">{formatCurrency(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Modal Tambah Transaksi */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-md rounded-2xl p-6 relative shadow-2xl"
            >
              <h3 className="text-xl font-bold mb-6">Tambah Transaksi</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex gap-2 p-1 bg-gray-100 rounded-xl">
                  <button 
                    type="button"
                    onClick={() => setFormData({ ...formData, type: 'expense' })}
                    className={cn(
                      "flex-1 py-2 rounded-lg text-sm font-semibold transition-all",
                      formData.type === 'expense' ? "bg-white text-red-600 shadow-sm" : "text-gray-500"
                    )}
                  >
                    Pengeluaran
                  </button>
                  <button 
                    type="button"
                    onClick={() => setFormData({ ...formData, type: 'income' })}
                    className={cn(
                      "flex-1 py-2 rounded-lg text-sm font-semibold transition-all",
                      formData.type === 'income' ? "bg-white text-green-600 shadow-sm" : "text-gray-500"
                    )}
                  >
                    Pemasukan
                  </button>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                    <Wallet className="w-3 h-3" /> Jumlah (IDR)
                  </label>
                  <input 
                    required
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="Contoh: 50000"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                      <Tag className="w-3 h-3" /> Kategori
                    </label>
                    <input 
                      required
                      type="text"
                      list="categories-list"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="Makan, Transport..."
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white"
                    />
                    <datalist id="categories-list">
                      <option value="Makanan & Minuman" />
                      <option value="Transportasi" />
                      <option value="Hiburan" />
                      <option value="Belanja" />
                      <option value="Kesehatan" />
                      <option value="Gaji" />
                      <option value="Bonus" />
                    </datalist>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                      <Calendar className="w-3 h-3" /> Tanggal
                    </label>
                    <input 
                      required
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                    <FileText className="w-3 h-3" /> Catatan
                  </label>
                  <textarea 
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Beli kopi di stasiun..."
                    rows={2}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white resize-none"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 mt-2"
                >
                  Simpan Transaksi
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Main() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return user ? <Dashboard /> : <Login />;
}

export default function App() {
  return (
    <AuthProvider>
      <Main />
    </AuthProvider>
  );
}
